function AttackMap() {
	$("#AttackMap").load("map");
}

function L7() {
	$("#l7").load("assets/pages/l7.php");
}

function L4() {
	$("#l4").load("assets/pages/l4.php");
}

AttackMap();
L7();
L4();