<?php

header('Location: https://stresser.pro');
die();

?>