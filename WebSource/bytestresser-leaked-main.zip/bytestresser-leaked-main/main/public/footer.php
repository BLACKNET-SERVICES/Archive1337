<?php

if(!defined('allow')) {
    header("HTTP/1.0 404 Not Found");
}

?>
                </div>
                <footer class="footer">
                    <div class="container-fluid text-center">
                         Copyright © <script>document.write(new Date().getFullYear())</script> <a href="https://bytestresser.com">ByteStresser.com</a>
                    </div>
                </footer>
            </div>
        </div>

        <div class="rightbar-overlay"></div>

        <script src="<?php echo $assets; ?>assets/libs/jquery/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
        <script src="<?php echo $assets; ?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo $assets; ?>assets/libs/node-waves/waves.min.js"></script>
        <script src="<?php echo $assets; ?>assets/libs/toastr/build/toastr.min.js"></script>
        <script src="<?php echo $assets; ?>assets/js/toastr.js"></script>
        <script src="<?php echo $assets; ?>assets/js/query.min.js"></script>
        <script src="<?php echo $assets; ?>assets/js/app.js"></script>
    </body>
</html>